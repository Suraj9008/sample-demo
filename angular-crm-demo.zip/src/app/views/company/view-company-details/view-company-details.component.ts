import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-company-details',
  templateUrl: './view-company-details.component.html',
  styleUrls: ['./view-company-details.component.scss']
})
export class ViewCompanyDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
