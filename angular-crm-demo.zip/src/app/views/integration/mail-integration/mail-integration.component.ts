import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mail-integration',
  templateUrl: './mail-integration.component.html',
  styleUrls: ['./mail-integration.component.scss']
})
export class MailIntegrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
