import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fb-pixel',
  templateUrl: './fb-pixel.component.html',
  styleUrls: ['./fb-pixel.component.scss']
})
export class FbPixelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
