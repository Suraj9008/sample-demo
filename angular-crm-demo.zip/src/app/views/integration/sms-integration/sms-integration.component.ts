import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sms-integration',
  templateUrl: './sms-integration.component.html',
  styleUrls: ['./sms-integration.component.scss']
})
export class SmsIntegrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
