import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mail-chimp',
  templateUrl: './mail-chimp.component.html',
  styleUrls: ['./mail-chimp.component.scss']
})
export class MailChimpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
