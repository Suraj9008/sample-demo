import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-template',
  templateUrl: 'emailTemplate.component.html',
})
export class EmailTemplateComponent implements OnInit {

  constructor() { }
  ngOnInit(): void {
  }
}
