import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-loan',
  templateUrl: './add-loan.component.html',
  styleUrls: ['./add-loan.component.scss']
})
export class AddLoanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
